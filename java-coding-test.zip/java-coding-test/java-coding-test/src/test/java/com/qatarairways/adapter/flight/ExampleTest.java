package com.qatarairways.adapter.flight;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

public class ExampleTest {

    @Test
    public void should_succeed() {
        assertThat(true).isTrue();
    }
}
