/**
 * 
 */
package com.flight.search;

import java.util.Date;

import lombok.Builder;
import lombok.Value;

/**
 * @author Souvik_Das
 *
 */

@Value
@Builder
public class FlightSearchRequest {

	private String origin;
	
	private String destination;
	
	private Date departureDate;
	
	private Integer numberOfTravellers;
	
	private Boolean isCancellationPossible;
	
	private float averagePrice; 
	
	private SortBy sortBy;
	
}
