package com.flight.search;

public enum SortBy {
	
	FLIGHTLENGTH("fltLength"),AVERAGEPRICE("avgPrice");
	
	private String name;

	SortBy(String string) {
		name = string;
	}

	public String getName() {
		return name;
	}
	
	

}
