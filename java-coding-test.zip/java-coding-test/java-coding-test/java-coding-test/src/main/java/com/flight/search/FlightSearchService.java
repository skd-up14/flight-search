package com.flight.search;

import java.util.List;

public interface FlightSearchService {
	
	List<String> getAvailableFlights(FlightSearchRequest flightSearchRequest);

}
