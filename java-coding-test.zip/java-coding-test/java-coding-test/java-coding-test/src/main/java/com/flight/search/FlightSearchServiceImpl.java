package com.flight.search;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.qatarairways.adapter.flight.FlightAvailabilityRequest;
import com.qatarairways.adapter.flight.FlightAvailabilityService;
import com.qatarairways.adapter.flight.FlightSummary;

public class FlightSearchServiceImpl implements FlightSearchService {

	FlightAvailabilityService flightAvailabilityService;

	public FlightSearchServiceImpl(FlightAvailabilityService flightAvailabilityService) {
		super();
		this.flightAvailabilityService = flightAvailabilityService;
	}

	/**
	 * This method returns the list of flights 
	 */
	@Override
	public List<String> getAvailableFlights(FlightSearchRequest flightSearchRequest) {
		Long DEFAULT_LIMIT = 4L;

		FlightAvailabilityRequest flightAvailabilityRequest = new FlightAvailabilityRequest(
				flightSearchRequest.getOrigin(), flightSearchRequest.getDestination(),
				flightSearchRequest.getDepartureDate(), flightSearchRequest.getNumberOfTravellers());

		Collection<FlightSummary> flightList = flightAvailabilityService.getAvailableFlights(flightAvailabilityRequest);

		if (flightList.isEmpty()) {
			return Collections.emptyList();
		}

		List<Predicate<FlightSummary>> flightSummaryPredicateList = new ArrayList<>();

		if (flightSearchRequest.getIsCancellationPossible() == Boolean.TRUE) {
			flightSummaryPredicateList.add(flight -> flight.isCancellationPossible() == Boolean.TRUE);
		}

		if (flightSearchRequest.getAveragePrice() > 0) {
			flightSummaryPredicateList
					.add(flight -> flight.getAveragePriceInUsd() <= flightSearchRequest.getAveragePrice());
		}

		if (flightSummaryPredicateList.size() > 0) {
			flightList = flightFilter(flightList, flightSummaryPredicateList);
		}

		Comparator<FlightSummary> comparator = Comparator.comparing(FlightSummary::getAveragePriceInUsd);
		if (flightSearchRequest.getSortBy().getName().equals(SortBy.FLIGHTLENGTH.getName())) {
			comparator = (FlightSummary flightSummary1,
					FlightSummary flightSummary2) -> (getFlightLength(flightSummary1)
							- getFlightLength(flightSummary2)) > 0 ? 1 : -1;
		} 

		flightList = flightSorter(flightList, comparator);

		return flightList.stream().limit(DEFAULT_LIMIT).map(x -> x.getAirlineCode()).collect(Collectors.toList());

	}

	/**
	 * 
	 * @param flightList
	 * @param predicates
	 * @return
	 */
	private Collection<FlightSummary> flightFilter(Collection<FlightSummary> flightList,
			List<Predicate<FlightSummary>> predicates) {
		return flightList.parallelStream().filter(predicates.stream().reduce(Predicate::and).orElse(predicates.get(0)))
				.collect(Collectors.toList());
	}

	/**
	 * 
	 * @param flightList
	 * @param comparator
	 * @return
	 */
	private Collection<FlightSummary> flightSorter(Collection<FlightSummary> flightList,
			Comparator<FlightSummary> comparator) {
		return flightList.parallelStream().sorted(comparator).collect(Collectors.toList());
	}

	/**
	 * 
	 * @param fltSumm
	 * @return
	 */
	private Integer getFlightLength(FlightSummary fltSumm) {
		return fltSumm.getArrivalTime().toInstant().getNano() - fltSumm.getDepartureTime().toInstant().getNano();
	}

}
