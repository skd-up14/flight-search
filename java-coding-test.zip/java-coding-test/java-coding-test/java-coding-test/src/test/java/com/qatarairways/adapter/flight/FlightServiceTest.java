package com.qatarairways.adapter.flight;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.flight.search.FlightSearchRequest;
import com.flight.search.FlightSearchService;
import com.flight.search.FlightSearchServiceImpl;
import com.flight.search.SortBy;

@ExtendWith(MockitoExtension.class)
@DisplayName("Asserts for Flight service")
class FlightServiceTest {

	@Mock
	static FlightAvailabilityService flightAvailabilityService;

	@InjectMocks
	FlightSearchService flightSearchService = new FlightSearchServiceImpl(flightAvailabilityService);
	
	@BeforeAll
	public static void init() {
		System.out.println("Starting FlightServiceTest");
		
	}
	
	@BeforeEach
	public void setMockOutput() {
		List<FlightSummary> flightSummaryList = new ArrayList<>();
		FlightSummary flightSummary1 = FlightSummary.builder().airlineCode("AA").arrivalTime(new Date(1656058838000L))
				.departureTime(new Date(1656045645000L)).averagePriceInUsd(230).cancellationPossible(true).build();
		FlightSummary flightSummary2 = FlightSummary.builder().airlineCode("DL").arrivalTime(new Date(1656053018000L))
				.departureTime(new Date(1656045645000L)).averagePriceInUsd(450).cancellationPossible(false).build();
		FlightSummary flightSummary3 = FlightSummary.builder().airlineCode("UA").arrivalTime(new Date(1656054938000L))
				.departureTime(new Date(1656045645000L)).averagePriceInUsd(100).cancellationPossible(true).build();
		FlightSummary flightSummary4 = FlightSummary.builder().airlineCode("SY").arrivalTime(new Date(1656053216000L))
				.departureTime(new Date(1656045645000L)).averagePriceInUsd(333).cancellationPossible(false).build();
		FlightSummary flightSummary5 = FlightSummary.builder().airlineCode("NK").arrivalTime(new Date(1656048923000L))
				.departureTime(new Date(1656045645000L)).averagePriceInUsd(560).cancellationPossible(true).build();
		FlightSummary flightSummary6 = FlightSummary.builder().airlineCode("WN").arrivalTime(new Date(1656048923000L))
				.departureTime(new Date(1656045645000L)).averagePriceInUsd(620).cancellationPossible(true).build();
		flightSummaryList.add(flightSummary1);
		flightSummaryList.add(flightSummary2);
		flightSummaryList.add(flightSummary3);
		flightSummaryList.add(flightSummary4);
		flightSummaryList.add(flightSummary5);
		flightSummaryList.add(flightSummary6);
		FlightAvailabilityRequest flightAvailabilityRequest = new FlightAvailabilityRequest("New York", "Texas",
				new Date(1656045645000L), 2);
		Mockito.lenient().when(flightAvailabilityService.getAvailableFlights(flightAvailabilityRequest))
				.thenReturn(flightSummaryList);
	}

	@Test
	@DisplayName("Should return empty list if there is no flight at requested departure time")
	public void testGetAvailableFlights_RequestDeptTimeNotMatching() {
		FlightSearchRequest flightSearchRequest = FlightSearchRequest.builder().averagePrice(100)
				.departureDate(new Date(1656140413000L)).origin("New York").destination("Texas")
				.isCancellationPossible(false).numberOfTravellers(2).sortBy(SortBy.AVERAGEPRICE).build();
		assertIterableEquals(Collections.EMPTY_LIST, flightSearchService.getAvailableFlights(flightSearchRequest));
	}

	@Test
	@DisplayName("Should return empty list if there is no flight for the requested origin")
	public void testGetAvailableFlights_RequestOriginNotMatching() {
		FlightSearchRequest flightSearchRequest = FlightSearchRequest.builder().averagePrice(340)
				.departureDate(new Date(1656045645000L)).origin("San Francisco").destination("Texas")
				.isCancellationPossible(false).numberOfTravellers(2).sortBy(SortBy.AVERAGEPRICE).build();
		assertIterableEquals(Collections.EMPTY_LIST, flightSearchService.getAvailableFlights(flightSearchRequest));
	}

	@Test
	@DisplayName("Should return empty list if there is no flight for the requested destination")
	public void testGetAvailableFlights_RequestDestNotMatching() {
		FlightSearchRequest flightSearchRequest = FlightSearchRequest.builder().averagePrice(222)
				.departureDate(new Date(1656045645000L)).origin("New York").destination("Los Angeles")
				.isCancellationPossible(false).numberOfTravellers(2).sortBy(SortBy.AVERAGEPRICE).build();
		assertIterableEquals(Collections.EMPTY_LIST, flightSearchService.getAvailableFlights(flightSearchRequest));
	}

	@Test
	@DisplayName("Should return empty list if there is no flight with price less than requested price")
	public void testGetAvailableFlights_RequestPriceLessThanAvbl() {
		FlightSearchRequest flightSearchRequest = FlightSearchRequest.builder().averagePrice(75)
				.departureDate(new Date(1656045645000L)).origin("New York").destination("Texas")
				.isCancellationPossible(false).numberOfTravellers(2).sortBy(SortBy.AVERAGEPRICE).build();
		assertIterableEquals(Collections.EMPTY_LIST, flightSearchService.getAvailableFlights(flightSearchRequest));
	}

	@Test
	@DisplayName("Should return non-empty list of flights when there are flights with price less than requested price")
	public void testGetAvailableFlights_RequestPriceMoreThanAvbl() {
		FlightSearchRequest flightSearchRequest = FlightSearchRequest.builder().averagePrice(500)
				.departureDate(new Date(1656045645000L)).origin("New York").destination("Texas")
				.isCancellationPossible(false).numberOfTravellers(2).sortBy(SortBy.AVERAGEPRICE).build();
		assertEquals(4, flightSearchService.getAvailableFlights(flightSearchRequest).size());
	}

	@Test
	@DisplayName("Should return empty list if there is no flight matching request")
	public void testGetAvailableFlights_AllRequestParameterNotMatching() {
		FlightSearchRequest flightSearchRequest = FlightSearchRequest.builder().averagePrice(100)
				.departureDate(new Date(1656045645000L)).origin("New Jersey").destination("Houston")
				.isCancellationPossible(false).numberOfTravellers(2).sortBy(SortBy.AVERAGEPRICE).build();
		assertIterableEquals(Collections.EMPTY_LIST, flightSearchService.getAvailableFlights(flightSearchRequest));
	}

	@Test
	@DisplayName("Should return only flights with cancellation possible")
	public void testGetAvailableFlights_IsCancellationPossibleTrue() {
		FlightSearchRequest flightSearchRequest = FlightSearchRequest.builder().averagePrice(450)
				.departureDate(new Date(1656045645000L)).origin("New York").destination("Texas")
				.isCancellationPossible(true).numberOfTravellers(2).sortBy(SortBy.AVERAGEPRICE).build();
		assertEquals(2, flightSearchService.getAvailableFlights(flightSearchRequest).size());
	}

	@Test
	@DisplayName("Should return flights irrespective of cancellation is possible or not")
	public void testGetAvailableFlights_IsCancellationPossibleFalse() {
		FlightSearchRequest flightSearchRequest = FlightSearchRequest.builder().averagePrice(450)
				.departureDate(new Date(1656045645000L)).origin("New York").destination("Texas")
				.isCancellationPossible(false).numberOfTravellers(2).sortBy(SortBy.AVERAGEPRICE).build();
		assertEquals(4, flightSearchService.getAvailableFlights(flightSearchRequest).size());
	}

	@Test
	@DisplayName("Should return non-empty list of flights when only price filter is requested")
	public void testGetAvailableFlights_OnlyPriceFilterInRequest() {
		FlightSearchRequest flightSearchRequest = FlightSearchRequest.builder().averagePrice(450)
				.departureDate(new Date(1656045645000L)).origin("New York").destination("Texas").numberOfTravellers(2)
				.sortBy(SortBy.AVERAGEPRICE).build();
		assertEquals(4, flightSearchService.getAvailableFlights(flightSearchRequest).size());
	}

	@Test
	@DisplayName("Should return non-empty list of flights when only cancellation filter is requested")
	public void testGetAvailableFlights_OnlyCancellationFilterInRequest() {
		FlightSearchRequest flightSearchRequest = FlightSearchRequest.builder().departureDate(new Date(1656045645000L))
				.origin("New York").destination("Texas").isCancellationPossible(true).numberOfTravellers(2)
				.sortBy(SortBy.AVERAGEPRICE).build();
		assertEquals(4, flightSearchService.getAvailableFlights(flightSearchRequest).size());
	}

	@Test
	@DisplayName("Should return non-empty list of flights when no filter(s) is/are requested")
	public void testGetAvailableFlights_NoFilterInRequest() {
		FlightSearchRequest flightSearchRequest = FlightSearchRequest.builder().departureDate(new Date(1656045645000L))
				.origin("New York").destination("Texas").numberOfTravellers(2).sortBy(SortBy.AVERAGEPRICE).build();
		assertEquals(4, flightSearchService.getAvailableFlights(flightSearchRequest).size());
	}
	
	//sorting tests
	@Test
	@DisplayName("Should contain the elements sorted by average price")
	public void testGetAvailableFlights_SortByAvgPrice() {
		FlightSearchRequest flightSearchRequest = FlightSearchRequest.builder().averagePrice(450).departureDate(new Date(1656045645000L))
				.origin("New York").destination("Texas").isCancellationPossible(true).numberOfTravellers(2)
				.sortBy(SortBy.AVERAGEPRICE).build();
		List<String> expectedList = List.of("UA","AA");
		assertIterableEquals(expectedList, flightSearchService.getAvailableFlights(flightSearchRequest));
	}
	
	@Test
	@DisplayName("Should contain the elements sorted by length of flight")
	public void testGetAvailableFlights_SortByFltLength() {
		FlightSearchRequest flightSearchRequest = FlightSearchRequest.builder().averagePrice(600).departureDate(new Date(1656045645000L))
				.origin("New York").destination("Texas").isCancellationPossible(true).numberOfTravellers(2)
				.sortBy(SortBy.FLIGHTLENGTH).build();
		List<String> expectedList = List.of("NK","UA","AA");
		assertIterableEquals(expectedList, flightSearchService.getAvailableFlights(flightSearchRequest));
	}
	
	@Test
	@DisplayName("Should return non-empty list of maximum length of 3")
	public void testGetAvailableFlights_ResponseHasMax3() {
		FlightSearchRequest flightSearchRequest = FlightSearchRequest.builder().averagePrice(700)
				.departureDate(new Date(1656045645000L)).origin("New York").destination("Texas")
				.isCancellationPossible(true).numberOfTravellers(2).sortBy(SortBy.AVERAGEPRICE).build();
		assertEquals(4, flightSearchService.getAvailableFlights(flightSearchRequest).size());
	}
	
}
